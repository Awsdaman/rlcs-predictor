# Handoff: EWC 2026 Rocket League Predictor — visual redesign

## Overview

This is a **visual-layer redesign** of an existing score-prediction web app used by a
private friend group during the Esports World Cup 2026 Rocket League tournament.

Players predict match scores before each match locks (30 min before start). Exact
score = 3 pts, correct winner only = 1 pt, wrong = 0. A leaderboard ranks the group.
One admin enters real results.

**The product structure is unchanged.** Same screens, same information, same
interactions, same data shapes. Only the visual treatment changed. Do not
restructure routing, state, or the data layer while implementing this.

## About the design files

The files in this bundle are **design references authored in HTML** — a prototype
showing intended look and behavior. They are **not production code to copy
verbatim**.

The existing app is **inline-styled React** (`src/App.jsx`, no CSS framework, no
stylesheet beyond a reset). The task is to port the visual decisions documented
here into that existing React codebase, using its established component structure
(`BracketCard`, `BracketTeamRow`, `CountdownPill`, `RoundCol`, `Slot`, `ElbowCol`,
etc. — see the component inventory in `reference/tokens.md`).

Every value below is expressible as a plain CSS property, so it maps directly onto
inline React style objects. **Do not** introduce Tailwind, a CSS framework, or
build-step features.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, borders, and shadows.
Recreate pixel-accurately using the codebase's existing patterns. Every hex value,
font size, letter-spacing, and padding in this document is intentional.

Two caveats:
- Team logos are intentionally absent. Colored initial chips stand in (see below).
  If the real app has logo assets, drop them into the same 24×24 chip footprint.
- The prototype has a Wide/Mobile viewport toggle in its header. That is a
  **demo affordance for reviewing both layouts in one file** — do not ship it.
  Responsive behavior in the real app comes from the viewport.

---

## Design tokens

All tokens are declared as CSS custom properties on the root wrapper of the
prototype. Values marked **changed** differ from `reference/tokens.md` (the
pre-redesign state).

### Brand — unchanged, fixed, not up for reinvention

| Token | Value | Use |
|---|---|---|
| `gold` | `#C8A86A` | Primary accent — active nav, selected card, winner emphasis |
| `goldLight` | `#F2C575` | Winner names, highest-emphasis text |
| `goldDark` | `#987C4B` | Gradient bottom stop |
| `goldDeep` | `#4E442D` | Deep gradient stop, rarely used |
| `orange` | `#FF5A1F` | Live / urgent states only |
| `red` | `#F4425C` | Sub-hour countdown, wrong picks, destructive actions |
| `blue` | `#5B8CFF` | "You" markers, informational |
| `green` | `#3ECF8E` | Exact-score success (+3) |

No new accent hue was introduced.

### Ink ramp — surfaces darkened slightly, two neutral steps added

Depth reads from **value**, not glow: page is darkest, cards step up in lightness.
Keep this principle.

| Token | Value | Change | Use |
|---|---|---|---|
| `bg` | `#17171A` | changed from `#1A1A1D` | Page base |
| `bgDeep` | `#121214` | changed from `#141417` | Header bar, wells, TBD card fill |
| `surface` | `#1F1F23` | changed from `#232327` | Standard cards |
| `surfaceHi` | `#28282D` | changed from `#2C2C31` | Raised / selected / live cards |
| `line` | `rgba(255,255,255,0.09)` | changed from `0.10` | Standard hairline border |
| `lineSoft` | `rgba(255,255,255,0.05)` | changed from `0.06` | Internal dividers |
| `lineStrong` | `rgba(255,255,255,0.18)` | **new** | Emphasised border (predict panel) |
| `conn` | `rgba(200,168,106,0.30)` | **new** | Bracket connector lines |

Surfaces were pulled down ~3 points so the gold accent and the new background
washes have more room before clipping.

### Text — one step added

| Token | Value | Change | Use |
|---|---|---|---|
| `white` | `#F7F7F8` | unchanged | Primary text |
| `muted` | `#9C9CA3` | changed from `#A0A0A6` | Secondary text, losing team names |
| `dim` | `#67676E` | changed from `#6E6E76` | Labels, metadata |
| `dimmer` | `#48484E` | **new** | TBD placeholders — recessed below `dim` |

`dimmer` is what lets TBD cards sink visually instead of competing with real ones.

### Page background — changed

Was a single gold wash from top-centre. Now three offset washes plus the base
gradient, giving the page directional light instead of a symmetric halo:

```css
background:
  radial-gradient(1000px 520px at 15% -8%,  rgba(200,168,106,0.12) 0%, transparent 55%),
  radial-gradient(900px 620px at 100% 30%,  rgba(255,90,31,0.05)   0%, transparent 60%),
  radial-gradient(1100px 700px at 50% 120%, rgba(200,168,106,0.06) 0%, transparent 60%),
  linear-gradient(180deg, #18181B 0%, #101012 100%);
background-attachment: fixed;
```

`background-attachment: fixed` keeps the wash anchored while content scrolls.

### Typography

Two Google fonts via `<link>`. Rajdhani carries all UI chrome; Inter carries prose.

```
Rajdhani  600,700   → headings, labels, team names, scores, all UI chrome
Inter     400,500,600 → body copy, prediction counts, longer prose
```

Type scale as implemented (all Rajdhani 700 unless noted):

| Context | Size | Tracking | Color | Change |
|---|---|---|---|---|
| Page wordmark | 19 | 1.5 uppercase | `white` | — |
| Event meta line | 10 | 2 uppercase | `dim` | — |
| Nav item | 11.5 | 1.2 uppercase | `muted` / `goldLight` active | — |
| Round label | 13 | 0.4 uppercase | `white` | **promoted** from 10px `gold` |
| Round sub-label (date) | 9 | 1.5 uppercase | `dim` | demoted |
| Bracket section header | 11 | 2 uppercase | `gold` / `orange` | **new** |
| Card header label | 9 | 1 uppercase | `dim` | — |
| Team name | 14 | 0.2 | `white` | **up** from 13.5 |
| Team name (winner) | 14 | 0.2 | `goldLight` | — |
| Team name (loser) | 14 | 0.2 | `muted` | — |
| Team name (TBD) | 14 | 0.2 | `dimmer` | — |
| Score | 22 | tabular-nums | `goldLight` win / `dim` loss | **up** from 20 |
| Logo chip initials | 9 | — | per-team hue | — |
| Status chip | 10 | 0.5 | per-state | — |
| Standings rank (1st) | 26 | tabular-nums | `gold` | **new** (was emoji) |
| Standings rank (other) | 22 | tabular-nums | `muted` / `dim` | **new** |
| Standings points | 28 / 24 | tabular-nums | `gold` / `white` | — |
| Grand Final team name | 17 | 0.2 | `dimmer` when TBD | **new** |

Scores and rank/points numerals use `font-variant-numeric: tabular-nums` so digits
don't shift as results land. **Keep that.**

### Layout constants

| Constant | Value | Change |
|---|---|---|
| Shell max width | `1440px` | — |
| Bracket card width | `300px` | changed from `320px` |
| Playoff QF/SF card width | `280px` | new (narrower, four columns to fit) |
| Playoff Grand Final card width | `300px` | new |
| Qualify marker column | `104px` | — |
| Card radius | `5px` | changed from `6px` |
| Card shadow (standard) | `0 1px 2px rgba(0,0,0,0.3)` | lightened |
| Card shadow (selected) | `0 5px 16px rgba(0,0,0,0.4)` | — |
| Card shadow (Grand Final) | `0 6px 20px rgba(0,0,0,0.4)` | new |
| Slot padding | `7px 0` (bracket), `6px 0` (playoffs) | — |
| Round header height | `44px` | — |
| Page gutter | `20px` | — |

---

## Bracket geometry — load-bearing, do not change

This was already correct in the existing app and is preserved exactly. It took real
effort to get right; understand it before touching it.

A round is a flex column of N equal `flex:1` slots. With N slots, card centres land
at `(2i+1)/2N` of the column height. A round with half as many slots therefore
lands **exactly** on each pair's midpoint, with no hard-coded card height anywhere.
That matters because card height varies (long team names wrap; admin mode adds a
debug line).

Connectors are real elbows drawn from those same percentages, inside a `flex:1`
column between rounds. Each elbow column contains two `flex:1` halves; each half
holds four absolutely-positioned 1px rules:

```
in-stub   left:0    width:50%  top:25%   height:1px
in-stub   left:0    width:50%  top:75%   height:1px
vertical  left:50%  width:1px  top:25%   height:50%
out-stub  left:50%  width:50%  top:50%   height:1px
```

Connector color is `--conn` = `rgba(200,168,106,0.30)`.

**Critical:** slots must not use `gap`. A 4-slot column accumulates three gaps
while its 2-unit connector column accumulates one, throwing joins off by ~2.5px.
Cards are spaced with symmetric `padding: 7px 0` on the slot, which spaces without
moving a centre.

For 1:1 progressions (LB round 1 → round 2, or a round → its "Advance" marker), a
single centred horizontal rule replaces the elbow:

```
left:0  right:0  top:50%  height:1px
```

Each elbow/line column starts with a `44px` spacer div so it aligns below the round
header. Bracket wrappers use `overflow-x: auto` with `min-width` on the inner row
(`900px` group stage, `1100px` playoffs) — the **page** must never scroll sideways.

---

## Screens

### 1. Header — persistent

Sticky at `top: 0`, `z-index: 50`. `rgba(18,18,20,0.94)` with
`backdrop-filter: blur(18px)`, bottom border `1px solid rgba(200,168,106,0.28)`
(gold-tinted, not neutral). Padding `14px 20px`, inner container `max-width: 1440px`,
`margin: 0 auto`.

Left column, stacked:
- Wordmark: `EWC 2026 · Rocket League` — the `·` separator is `gold`, rest `white`
- Meta line: `Aug 12–16 · Riyadh · $1,000,000 · 16 Teams`
- Nav row: `display:flex; gap:4px; flex-wrap:wrap`, five buttons

Nav button, inactive:
```css
padding: 7px 14px; border: none; background: none;
border-bottom: 2px solid transparent; border-radius: 5px 5px 0 0;
color: #9C9CA3; font: 700 11.5px Rajdhani; letter-spacing: 1.2px;
text-transform: uppercase; cursor: pointer;
```
Active: `border-bottom-color: var(--gold)`, `background: rgba(200,168,106,0.12)`,
`color: var(--goldLight)`.

Nav items: Group Stage · Playoffs · My Group · Standings · Others' Picks.

Right column is the **prototype-only** viewport toggle — omit in production.

### 2. Momentum strip — NEW

Sits directly below the header. This is the main *new* element: the brief noted
nothing conveyed tournament momentum.

Container: `border-bottom: 1px solid var(--lineSoft)`, `background: rgba(0,0,0,0.15)`,
padding `14px 20px`, inner `max-width: 1440px`.

Row of five day nodes (Aug 12–16) connected by `26px × 1px` rules. Each node is a
column: dot on top, date label below, `gap: 6px`.

| Day state | Dot | Connector to next | Label color |
|---|---|---|---|
| Past | `9px` circle, filled `gold` | `1px` solid `gold` | `muted` |
| Current | `11px` circle, filled `gold`, `box-shadow: 0 0 0 3px rgba(200,168,106,0.22)`, pulse animation | `1px` solid `lineStrong` | `goldLight`, weight 700 |
| Next | `9px` circle, `1px solid lineStrong`, no fill | `1px` solid `lineStrong` | `dim` |
| Future | `9px` circle, `1px dashed lineStrong`, no fill | `1px` solid `lineStrong` | `dimmer` |

Connector rules carry `margin: 0 2px 17px` so they align to dot centres, not the
column centre.

Then a `22px × 1px` vertical divider (`lineSoft`), then a status line in Inter 12px
`muted`: `Day 2 of 5 · **Group Stage** — 5 of 28 matches decided` (stage name in
`white`, weight 600).

Pulse keyframe (the only animation in the design, used here and on the LIVE dot):
```css
@keyframes ewcPulse { 0%,100% { opacity:1 } 50% { opacity:.35 } }
/* momentum current-day dot: 1.8s ease-in-out infinite */
/* LIVE chip dot:            1.4s ease-in-out infinite */
```

### 3. Group Stage — the hero screen

Controls row: Group A / Group B pills on the left, Bracket / Schedule segmented
control on the right, `flex-wrap: wrap`, `margin-bottom: 18px`.

Active group pill:
```css
padding: 8px 20px; border: none; border-radius: 6px; color: #151515;
background: linear-gradient(135deg, #F2C575 0%, #C8A86A 55%, #987C4B 100%);
font: 700 12px Rajdhani; letter-spacing: 1px; text-transform: uppercase;
```
Inactive: `1px solid var(--line)`, `background: rgba(255,255,255,0.03)`,
`color: var(--muted)`.

Segmented control: container `background: var(--surface)`,
`border: 1px solid var(--line)`, `border-radius: 8px`, `padding: 3px`, `gap: 3px`.
Active segment: `background: rgba(200,168,106,0.16)`, `color: var(--gold)`,
`border-radius: 6px`, `padding: 6px 18px`. Inactive: transparent, `color: var(--muted)`.

Caption line below, Rajdhani 10px `dim` uppercase, tracking 1.5:
`Group A · Aug 12–14 · All Bo5 · Top 4 advance · ` + `Click any match to predict`
in `gold`.

#### Bracket section headers — NEW

Each half of the bracket gets a labelled rule, giving the page rhythm the old
design lacked:

```
[UPPER BRACKET]  ──────────────────────────  (gold, 11px, tracking 2)
[LOWER BRACKET — ELIMINATION]  ───────────   (orange, 11px, tracking 2)
```
Label + `height:1px; flex:1; background: var(--lineSoft)` rule, `gap: 14px`,
`margin-bottom: 8px`.

#### Bracket tint washes — NEW

Each scroll container carries a directional wash so the two halves read as
different zones without adding a hue:

```css
/* upper bracket */
background: radial-gradient(700px 300px at 0% 0%, rgba(200,168,106,0.07) 0%, transparent 65%);
/* lower bracket */
background: radial-gradient(700px 300px at 0% 0%, rgba(255,90,31,0.06) 0%, transparent 65%);
/* playoffs */
background: radial-gradient(900px 400px at 100% 0%, rgba(200,168,106,0.08) 0%, transparent 60%);
```
Each with `border-radius: 10px` and `padding: 6px` on the inner row.

Upper bracket: 4 QF → 2 SF → Advance markers, `margin-bottom: 38px`.
Lower bracket: 2 R1 → 2 R2 → Advance markers.

#### Match card anatomy

```
┌─────────────────────────────────────┐
│ UB QUARTER FINAL 1        [ +3 ]    │  header: label + status chip
├─────────────────────────────────────┤
│ [TM]  Twisted Minds              3  │  team row (winner)
├─────────────────────────────────────┤
│ [FUT] FUT Esports                1  │  team row (loser)
└─────────────────────────────────────┘
```

Card shell: `background: var(--surface)`, `border-radius: 5px`,
`overflow: hidden`, `box-shadow: 0 1px 2px rgba(0,0,0,0.3)`, border per state.

Header: `padding: 6px 12px`, `background: rgba(0,0,0,0.22)`,
`border-bottom: 1px solid var(--lineSoft)`, `display:flex`,
`justify-content: space-between`, `align-items: center`, `gap: 8px`.
Label Rajdhani 9px 700 `dim` uppercase tracking 1 (→ `gold` when selected).

Team row: `padding: 9px 12px`, `display:flex`, `align-items:center`,
`justify-content: space-between`, `gap: 10px`. Rows separated by
`1px solid var(--lineSoft)`. Winner row gets `background: rgba(200,168,106,0.06)`.

Logo chip: `24×24`, `border-radius: 4px`, centred Rajdhani 9px 700 initials,
`flex-shrink: 0`, per-team dark fill + `44`-alpha hex border + full-strength text
in the team's hue. Losing team's chip gets `opacity: .6`.

Team name: `white-space: nowrap; overflow: hidden; text-overflow: ellipsis` on a
`min-width: 0` flex parent. Names are long and several end in "Esports" — **never
truncate to the last word**; ellipsis the tail.

Team hues used in the prototype (fill / border / text):

| Team | Fill | Hue |
|---|---|---|
| Twisted Minds | `#1a0010` | `#FF3D6E` |
| FUT Esports | `#1a0000` | `#C8102E` |
| Shopify Rebellion | `#0d1a00` | `#96BF48` |
| Ninjas in Pyjamas | `#0d1400` | `#CCFF00` |
| Vitality | `#1a1400` | `#FFD700` |
| FURIA Esports | `#0a0a0a` | `#ffffff` |
| NRG Esports | `#1a0800` | `#FF6600` |
| TSM | `#0a1628` | `#3498DB` |
| Karmine Corp | `#001a2e` | `#00CFFF` |
| Wildcard | `#00091a` | `#1E90FF` |
| MIBR | `#001a0d` | `#00A651` |
| Spacestation Gaming | `#1a1000` | `#F5A623` |
| Gentle Mates | `#1a0800` | `#FF6B35` |
| Five Fears | `#001520` | `#00BFFF` |

Border format: hue + `44` (e.g. `1px solid #FF3D6E44`).

#### Card states — the core of the redesign

The old design weighted every card identically. Now weight maps to stakes:

| State | Card border | Fill | Header chip |
|---|---|---|---|
| **Countdown** (>1h) | `1px solid var(--line)` | `surface` | `Locks in 21h 40m` — `muted` text, `rgba(255,255,255,0.04)` fill, `1px solid var(--line)`, radius 4, `padding: 3px 8px` |
| **Countdown urgent** (<1h) | `1px solid var(--line)` | `surface` | `42m 10s` — `red` text, `rgba(244,66,92,0.12)` fill, `1px solid rgba(244,66,92,0.4)` |
| **Live** | `1px solid rgba(255,90,31,0.4)` | `surfaceHi` | `● LIVE` — `orange` text, `rgba(255,90,31,0.12)` fill, `1px solid rgba(255,90,31,0.4)`; `5px` dot with `ewcPulse 1.4s` |
| **Locked, no result** | `1px solid var(--line)` | `surface` | `LOCKED` — plain text, Rajdhani 9.5px `dim` uppercase tracking 1, **no chip** |
| **Selected** | `1.5px solid var(--gold)` | `surfaceHi` | header label turns `gold`; shadow `0 5px 16px rgba(0,0,0,0.4)` |
| **Scored +3** (exact) | `1px solid rgba(62,207,142,0.4)` | `surface` | `+3` — `green` text, `rgba(62,207,142,0.14)` fill, radius 4 |
| **Scored +1** (winner only) | `1px solid rgba(200,168,106,0.4)` | `surface` | `+1` — `gold` text, `rgba(200,168,106,0.14)` fill |
| **Scored 0** (wrong) | `1px solid var(--line)` | `surface` | `+0` — `dim` text, no fill |
| **TBD** | `1px dashed var(--lineSoft)` | `bgDeep` | label in `dimmer`, no chip, no shadow |

Three deliberate distinctions:
1. **LOCKED is plain text, not a chip.** It previously sat in the same chip family
   as countdowns and was hard to tell apart at a glance. Chips now mean "something
   is happening or was earned"; locked-and-waiting is absence of both.
2. **TBD sinks.** `bgDeep` fill (darker than the page base), dashed hairlines
   throughout — including the row dividers and a `24×24` dashed empty chip where
   the logo would be — `dimmer` text, and no shadow. A dead slot no longer competes
   with the Grand Final.
3. **Result borders carry the outcome hue** at `0.4` alpha, so scanning a column
   tells you how you did before reading a single number.

**Your pick** marker (on a card before the result lands): right-aligned chip in the
team row, Rajdhani 9px 700 `gold` tracking 1, `1px solid rgba(200,168,106,0.45)`,
`border-radius: 3px`, `padding: 3px 7px`, text `YOUR PICK`.

#### Round header

```
QUARTER FINALS        ← Rajdhani 13px 700, white, tracking 0.4, uppercase
AUG 12                ← Rajdhani 9px 700, dim, tracking 1.5, uppercase
```
`44px` tall, `display:flex; flex-direction:column; justify-content:flex-end;
padding-bottom:10px`. Lower-bracket round labels use `orange` instead of `white`.

This inverts the old hierarchy — the round label was 10px gold, the same visual
register as every other label on the card. Now the round name leads and the date
supports.

#### Advance / Qualify markers

`104px` column. Qualified: `1px dashed rgba(200,168,106,0.4)`,
`background: rgba(200,168,106,0.05)`, `border-radius: 4px`, `padding: 8px 10px`,
centred Rajdhani 9px 700 `gold` uppercase tracking 1.2, text `QUALIFIED`.
Pending: `1px dashed var(--lineSoft)`, no fill, `dimmer` text, `PENDING`.

### 4. Schedule view — rebuilt

Toggled from the Bracket/Schedule segmented control. Previously a bare meta-line
next to an engineered bracket; now a proper timeline.

Day header: bold label + flexible rule + right meta, `gap: 12px`,
`margin-bottom: 14px`:
`**WEDNESDAY, AUG 12**  ─────────────  4 MATCHES · KSA`

Each row: `display:flex; gap:12px; padding:12px 0`, separated by
`1px solid var(--lineSoft)` (last row none).

- **Time gutter**: `width: 64px`, `flex-shrink: 0`, `text-align: right`.
  Time in Rajdhani 16px 700 tabular-nums; status word below in Rajdhani 9px.
  Both take the state color — `white`/`green` finished, `orange` live,
  `red` urgent, `white`/`muted` upcoming.
- **Vertical rule**: `1px` `lineSoft`, full row height, `flex-shrink: 0`.
- **Body**: round label line (Rajdhani 9px `dim` uppercase tracking 1,
  `margin-bottom: 6px` — turns `gold` and gains ` · SELECTED` when selected), then
  the fixture row: home cluster (chip + name), centre score or `vs`, away cluster
  (name + chip, reversed). `justify-content: space-between`.

Finished fixtures show `3 – 1` in Rajdhani 15px 700 tabular-nums `goldLight`, with
the winner's name `goldLight` and the loser's `muted` + `opacity:.6` chip.
Unplayed show `vs` in Rajdhani 12px `dim`, both names `white`.

Times are stored UTC and always displayed in **KSA (Asia/Riyadh, UTC+3)**.
Lock time is derived as `startTime − 30min` and never stored.

### 5. Predict panel

Opens under the selected card. `background: var(--surface)`,
`border: 1px solid var(--lineStrong)`, `border-radius: 8px`, `padding: 18px 20px`,
`max-width: 520px`.

- Title row: `Group A · UB Quarter Final 4 — Bo5` (Rajdhani 13px 700 `white`
  uppercase tracking 1) + `✕` close in `dim`, `justify-content: space-between`
- Meta: `Starts Aug 12, 05:20 PM KSA · Locks 04:50 PM KSA` — Rajdhani 10px `dim`
  tracking 1, `margin-bottom: 16px`
- Score inputs: two `52px` fields, `text-align: center`, Rajdhani 22px 700,
  `padding: 8px 0`, `background: rgba(255,255,255,0.04)`,
  `1px solid var(--line)`, `border-radius: 6px`, `color: var(--white)`,
  separated by a `:` in `dim` 16px. Centred, `gap: 10px`
- Winner buttons: two `flex: 1`, `padding: 10px 0`, `border-radius: 6px`,
  Rajdhani 12px 700 uppercase tracking 1, `gap: 8px`.
  Selected: `background: var(--gold)`, `border: 1px solid var(--gold)`,
  `color: #151515`. Unselected: `rgba(255,255,255,0.03)`,
  `1px solid var(--line)`, `color: var(--muted)`

Series length: group stage Bo5 (first to 3), playoffs Bo7 (first to 4).
Scoring: exact `3`, winner only `1`, wrong `0`. Total = prediction points + bonus.

### 6. Playoffs

Caption: `Playoffs · Aug 15–16 · Single elimination · All Bo7`.

4 QF (`280px`) → elbows → 2 SF (`280px`) → elbow → Grand Final column (`300px`).
Inner row `min-width: 1100px`. Same slot/elbow primitives; slot padding `6px 0`.

**Grand Final card** — the one card allowed extra weight:
```css
background: var(--surfaceHi);
border-top: 2px solid var(--gold);
border-left/right/bottom: 1px solid var(--line);
border-radius: 5px;
box-shadow: 0 6px 20px rgba(0,0,0,0.4);
```
Header: `padding: 8px 14px`, `background: rgba(200,168,106,0.08)`,
`border-bottom: 1px solid var(--lineSoft)`, label `GRAND FINAL · BO7` in Rajdhani
10px 700 `gold` tracking 1.5.
Team rows: `padding: 12px 14px`, `28×28` chips, team names **17px**.

The gold top edge is the only place a colored border-top appears — it marks the
terminal match without resorting to glow.

**3rd-place match** sits below the Grand Final in the same column,
`flex: 0 0 auto`, `gap: 14px` between them. Standard TBD treatment, header
`3RD PLACE MATCH · BO5`, team names 13px.

### 7. Standings

Caption: `Global standings · 7 players · Updated live`.

Container: `background: var(--surface)`, `border: 1px solid var(--line)`,
`border-radius: 8px`, `overflow: hidden`.

Rows: `display:flex; align-items:center; gap:18px`. First place `padding: 18px 20px`
with `background: linear-gradient(90deg, rgba(200,168,106,0.10), transparent)`.
Subsequent rows `padding: 16px 20px`, `border-top: 1px solid var(--lineSoft)`,
no fill.

Three zones:
1. **Rank** — `width: 34px`, `text-align: center`, Rajdhani 700 tabular-nums,
   zero-padded (`01`, `02`). 1st: 26px `gold`. 2nd–3rd: 22px `muted`.
   4th+: 22px `dim`. **Emoji medals were removed** — they were structural labels
   made of emoji, which the brief explicitly rejects.
2. **Identity** — `flex: 1`, `min-width: 0`. Name (Rajdhani 700, 16px for 1st
   else 15px, `white`) followed by badges in a `gap: 8px` wrapping row. Below, in
   Inter 11.5px `muted`: `21/28 predicted` plus ` · +2 bonus` / ` · −3 bonus` when
   an adjustment exists.
3. **Points** — Rajdhani 700 tabular-nums, 28px `gold` for 1st else 24px `white`,
   with a `PTS` suffix in 11px `dim`, `margin-left: 4px`, tracking 1.

Badges: `font-size: 9px`, `padding: 2px 7px`, `border-radius: 3px`, tracking 1,
weight 700.
- `YOU` — `blue` text, `rgba(91,140,255,0.15)` fill, `1px solid rgba(91,140,255,0.35)`
- Group badge (e.g. `ALZAIDY`) — `gold` text, `rgba(200,168,106,0.15)` fill,
  `1px solid rgba(200,168,106,0.3)`

### 8. My Group / Others' Picks

Not restyled in this artifact — they render a dashed placeholder in the prototype.
Structure and content are unchanged from the current app; apply the same card,
badge, and type treatments documented above when you get to them.

The **Admin** screens (six tabs) are likewise untouched.

---

## Interactions & behavior

| Trigger | Result |
|---|---|
| Click nav item | Switch screen; active item gains gold underline + tint |
| Click Group A / B | Swap bracket dataset |
| Click Bracket / Schedule | Swap group-stage view mode |
| Click a match card | Select it (gold `1.5px` border, `surfaceHi`, raised shadow) and open the predict panel beneath it |
| Click a winner button | Set predicted winner |
| Edit score inputs | Set predicted scores; nullable |
| Click `✕` | Close predict panel, deselect card |

Cards are only clickable when the match is predictable — not `TBD`, not `LOCKED`,
not finished.

Card hover: `surface` → `surfaceHi`. No transitions were specified beyond the two
`ewcPulse` loops; if you add any, keep them under 150ms and limit them to
`background-color` and `border-color`.

**Responsive:** brackets scroll horizontally inside their own `overflow-x: auto`
container with `min-width` on the inner row. The page itself must never scroll
sideways. The header nav and controls rows use `flex-wrap: wrap`. Mobile matters
most — this is used on phones during a live tournament, glanced at between games.

## State management

Unchanged from the existing app. The prototype adds only view-level state:

```js
{ nav: 'group'|'playoffs'|'mygroup'|'standings'|'others',
  view: 'bracket'|'schedule',
  group: 'A'|'B',
  selectedMatchId: string|null }
```

Existing data shapes are unchanged:

```js
match  = { id, group?, round, label, team1, team2, startTime /* UTC ISO */, bo }
result = { winner, score1, score2 }
pred   = { winner, score1, score2 }        // score1/2 nullable
player = { id, nickname, group_id, joined_at, last_seen }
```

Derived, not stored: lock time (`startTime − 30min`), card state, points.

## Assets

None. No external images, no CDN-hosted images, no SVG illustrations.

- **Team logos**: absent by design. Colored initial chips stand in (table above).
  If real logo assets exist, use the same `24×24` / `28×28` footprint and keep the
  chip's border color as a fallback ring.
- **Fonts**: Rajdhani (600, 700) and Inter (400, 500, 600) from Google Fonts.
  If the target app must be fully offline, self-host both.
- **Scrollbar**: styled via `::-webkit-scrollbar` — `8px`, track `#121214`,
  thumb `#5c4d31` at `4px` radius.

## What was deliberately avoided

The brief lists prior regressions. None of these appear in the redesign, and they
should not be reintroduced:

- Glow / neon box-shadows on every surface
- Gradient-filled heading text
- Emoji standing in for structural labels
- Uniform heavy letter-spacing on all text
- Large border radii
- Purple-to-blue gradients

Depth reads from **value** (`#17171A` page → `#1F1F23` card → `#28282D` raised)
plus one hairline border. Preserve that model.

## Files

| File | What it is |
|---|---|
| `EWC Predictor Redesign.dc.html` | **The redesign.** Open in a browser. Contains all screens, both layouts, and every card state in a side-by-side state gallery near the bottom of the Group Stage view. |
| `reference/preview-before.html` | The pre-redesign mock, for before/after comparison. |
| `reference/tokens.md` | Original token + geometry documentation from the existing app. |
| `reference/BRIEF.md` | The original design brief, including constraints and rejected directions. |

The redesign file has two review aids that are **not part of the design**:
- A **Wide / Mobile** viewport toggle in the header
- A **state gallery** section (`Every card state, side by side`) and an isolated
  **predict panel** specimen, both below the bracket

Ship neither. They exist so every state is visible in one page without needing to
drive the app into it.
